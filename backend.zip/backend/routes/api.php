<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\VehicleController;


Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout']);


Route::apiResource('vehicles', VehicleController::class);

//Route::middleware('auth:sanctum')->apiResource('vehicles', VehicleController::class);




// Route::post('/login', function (Request $request) {
//     $credentials = $request->validate([
//         'email' => ['required', 'email'],
//         'password' => ['required'],
//     ]);

//     if (!Auth::attempt($credentials)) {
//         return response()->json(['message' => 'Invalid credentials'], 401);
//     }

//     $request->session()->regenerate();
//     return response()->json(['message' => 'Login successful'], 200);
// });

// Route::post('/logout', function (Request $request) {
//     Auth::guard('web')->logout();
//     $request->session()->invalidate();
//     $request->session()->regenerateToken();
//     return response()->json(['message' => 'Logged out']);
// });

use Laravel\Sanctum\Http\Middleware\EnsureFrontendRequestsAreStateful;

Route::middleware([EnsureFrontendRequestsAreStateful::class])->group(function () {
    // Place your authenticated routes here
}); 

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();;
// });
