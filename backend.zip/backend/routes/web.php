<?php

use Illuminate\Support\Facades\Route;

Route::middleware(['web'])->group(function () {
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/logout', [AuthController::class, 'logout']);
});

use App\Http\Middleware\SessionMiddleware;

Route::middleware([SessionMiddleware::class])->group(function () {
    Route::post('/login', [AuthController::class, 'login']);
});



require __DIR__.'/auth.php';
