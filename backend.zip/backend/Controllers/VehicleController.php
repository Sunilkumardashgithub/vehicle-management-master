<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Vehicle;
use Illuminate\Http\Request;


class VehicleController extends Controller
{
    // Get all vehicles
    public function index()
    {
        return Vehicle::all();
    }

    // Store a new vehicle
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|string',
            'model' => 'required|string',
            'manufacturer' => 'required|string',
            'year' => 'required|integer',
        ]);

        return Vehicle::create($validatedData);
    }

    // Get a specific vehicle
    public function show($id)
    {
        return Vehicle::findOrFail($id);
    }

    // Update a vehicle
    public function update(Request $request, $id)
    {
        $vehicle = Vehicle::findOrFail($id);

        $vehicle->update($request->all());

        return $vehicle;
    }

    // Delete a vehicle
    public function destroy($id)
    {
        $vehicle = Vehicle::findOrFail($id);
        $vehicle->delete();

        return response()->json(['message' => 'Vehicle deleted successfully']);
    }
}
